package com.apiWebAutomation.runners;

import org.junit.platform.suite.api.*;

@Suite
@IncludeEngines("cucumber")
@SelectClasspathResource("/Users/abnish/Desktop/api-web-automation/src/test/resources/features") // <-- Add full path here
@ConfigurationParameter(key = "cucumber.glue", value = "com.apiWebAutomation.stepdefs")
public class CucumberTest {
}
